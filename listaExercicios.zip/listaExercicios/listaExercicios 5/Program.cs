﻿Console.WriteLine("digite um numero de 1 a 3 : ");
int num = int.Parse(Console.ReadLine());
string saudacao = Console.ReadLine();
switch (saudacao)
{
    case "1":
        Console.WriteLine("bom dia");
        break;
    case "2":
        Console.WriteLine("boa tarde");
        break;
    case "3":
        Console.WriteLine("boa noite");
        break;
    default:
        Console.WriteLine("opcao invalida");
        break ;
}