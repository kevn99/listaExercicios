﻿Console.WriteLine("digite um numero: ");
int numero = int.Parse(Console.ReadLine());

if (numero >= 7)
{
    Console.WriteLine("aprovado");
}
else if (numero < 7 && numero >= 4)
{
    Console.WriteLine("em recuperacao");
}
else  
{
    Console.WriteLine("reprovado");
}