int PERT, otimista, pessimista, provavel = 0;
Console.WriteLine("digite a hora otimista: ");
otimista = int.Parse(Console.ReadLine());

Console.WriteLine("digite a hora pessimista: ");
pessimista = int.Parse(Console.ReadLine());

Console.WriteLine("digite a hora provavel: ");
provavel = int.Parse(Console.ReadLine());

PERT = (otimista + pessimista(4* provavel))/6 ;

Console.WriteLine("o PERT � de : " + PERT);
