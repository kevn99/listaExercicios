﻿Console.WriteLine("digite um numero: ");
int numero = int.Parse(Console.ReadLine());

int soma = 0;

for (int i = 0; i <= numero; i = i+2)
{
    soma += 1;
}

Console.WriteLine($" o valor da soma é: {soma}");