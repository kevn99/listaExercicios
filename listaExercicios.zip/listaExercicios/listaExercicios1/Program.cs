﻿//double area, base1, altura = 0;
//Console.WriteLine("digite a base do triangulo retangulo: ");
//base1 = double.Parse(Console.ReadLine());
//Console.WriteLine("digite a altura do triangulo retangulo: ");
//altura = double.Parse(Console.ReadLine());
//area = (base1 * altura)/2;
//Console.WriteLine("a area do triangulo retangulo é: "+ area);


//double area, raio = 0;
//Console.WriteLine("digite o raio do circulo: ");
//raio = double.Parse(Console.ReadLine());

//area = Math.Pow(raio, 2) * 3.14;
//Console.WriteLine("a area do circulo é: ",+ area);

//double area, base1, base2, altura = 0;
//Console.WriteLine("digite a base1 do trapezio: ");
//base1 = double.Parse(Console.ReadLine());
//Console.WriteLine("digite a base2 do trapezio: ");
//base2 = double.Parse(Console.ReadLine());
//Console.WriteLine("digite a altura do trapezio: ");
//altura = double.Parse(Console.ReadLine());

//area = ((base1 + base2) * altura) / 2;
//Console.WriteLine("a area do trapezio é: " + area);

//double area, ladoQuadrado = 0;
//Console.WriteLine("digite o lado do quadrado: ");
//ladoQuadrado = double.Parse(Console.ReadLine());

//area = Math.Pow(ladoQuadrado, 2);
//Console.WriteLine("a area do quadrado é: " + area);

//double area, base1, altura = 0;
//Console.WriteLine("digite a base do retangulo");
//base1 = double.Parse(Console.ReadLine());
//Console.WriteLine("digite a altura do retangulo");
//altura = double.Parse(Console.ReadLine());

//area = base1 * altura;
//Console.WriteLine("a area do retangulo é: " + area);




